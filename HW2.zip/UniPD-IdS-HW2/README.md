# UniPD-IdS-HW2
Repository per homework 2 di corso di Ingegneria del Software di UniPD.

## Istruzioni
- Eseguire lo script _init.sh_ tramite il comando:
    ```
    ./init.sh
    ```
- Generare le metriche per le varie versioni del progetto eseguendo lo script _metrics.sh_:
    ```
    ./metrics.sh
    ```